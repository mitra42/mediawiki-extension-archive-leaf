Changelog
=========


7.0 alpha 1
===

* Supports MediaWiki 1.29

* Re organise the skin.

* Reduces code duplication in some places.

* Gets rid of two or more js files which should result in less proccessing by the browser
depending on which config you use to load which module.

* And more changes.
